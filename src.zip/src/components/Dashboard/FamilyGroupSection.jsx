import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';

const FamilyGroupSection = ({ currentPerson }) => {
  const [members, setMembers] = useState([]);
  const [formData, setFormData] = useState({ nombre: '', dni: '', vinculo: '', observaciones: '' });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (currentPerson) loadMembers();
    else setMembers([]);
  }, [currentPerson]);

  const loadMembers = async () => {
    const { data } = await supabase.from('family_members').select('*').eq('person_id', currentPerson.id).order('created_at');
    setMembers(data || []);
  };

  const handleAdd = async (e) => {
    e.preventDefault();
    if (!currentPerson) return;
    setLoading(true);
    await supabase.from('family_members').insert({
      person_id: currentPerson.id,
      apellido_nombres: formData.nombre,
      dni: formData.dni,
      vinculo: formData.vinculo,
      observaciones: formData.observaciones
    });
    setFormData({ nombre: '', dni: '', vinculo: '', observaciones: '' });
    loadMembers();
    setLoading(false);
  };

  return (
    <section className="card space-y-6">
      <div className="flex items-center justify-between border-b border-white/5 pb-4">
        <h2 className="text-lg font-bold text-white">Grupo Familiar</h2>
        <span className="text-[10px] font-bold text-muted uppercase tracking-widest">{members.length} integrantes</span>
      </div>

      <form onSubmit={handleAdd} className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <label>Nombre y Apellido</label>
            <input 
              placeholder="Nombre completo" 
              value={formData.nombre}
              onChange={(e) => setFormData({...formData, nombre: e.target.value})}
              required
              disabled={!currentPerson}
              className="py-2! text-xs"
            />
          </div>
          <div className="space-y-1.5">
            <label>DNI</label>
            <input 
              placeholder="DNI" 
              value={formData.dni}
              onChange={(e) => setFormData({...formData, dni: e.target.value})}
              disabled={!currentPerson}
              className="py-2! text-xs"
            />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <label>Vínculo</label>
            <input 
              placeholder="Ej: Hijo, Cónyuge, Madre..." 
              value={formData.vinculo}
              onChange={(e) => setFormData({...formData, vinculo: e.target.value})}
              disabled={!currentPerson}
              className="py-2! text-xs"
            />
          </div>
          <div className="space-y-1.5">
            <label>Observaciones</label>
            <input 
              placeholder="Ej: Discapacidad, medicación..." 
              value={formData.observaciones}
              onChange={(e) => setFormData({...formData, observaciones: e.target.value})}
              disabled={!currentPerson}
              className="py-2! text-xs"
            />
          </div>
        </div>
        <button className="primary w-full py-2! text-xs" type="submit" disabled={loading || !currentPerson}>
          {loading ? 'Agregando...' : 'Agregar Integrante'}
        </button>
      </form>

      <div className="tableWrap bg-black/40! mt-4 overflow-x-auto">
        <table className="w-full min-w-[300px]">
          <thead>
            <tr><th>Nombre</th><th>DNI</th><th>Vínculo</th><th>Observaciones</th></tr>
          </thead>
          <tbody>
            {members.length > 0 ? members.map(m => (
              <tr key={m.id}>
                <td className="font-bold text-white text-xs">{m.apellido_nombres}</td>
                <td className="text-[10px]">{m.dni || '-'}</td>
                <td className="text-[10px] opacity-60">{m.vinculo || '-'}</td>
                <td className="text-[10px] opacity-60">{m.observaciones || '-'}</td>
              </tr>
            )) : (
              <tr><td colSpan="4" className="text-center py-8 text-muted/40 text-xs italic">No hay integrantes.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </section>
  );
};

export default FamilyGroupSection;